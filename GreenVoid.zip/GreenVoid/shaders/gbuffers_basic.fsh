#version 120
void main() {
    gl_FragData[0] = vec4(0.0, 0.694, 0.251, 1.0);
}
